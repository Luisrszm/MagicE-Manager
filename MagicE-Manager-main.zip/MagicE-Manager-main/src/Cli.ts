import inquirer from 'inquirer'
import { pool, connectToDB } from './connection.js'

class Cli {

    constructor(){}
    
    // View departments table function
    async viewDep() {
        
    };

    // View roles table function
    async viewRol() {
        
    };

    // View employees table function
    async viewEmp() {
        
    };

    // Add department function
    async addDep() {
        
    };

    // Add role function
    async AddRol() {
        
    };

    // Add employee function
    async addEmp() {
        
    };

    // Edit employee role function
    async editEmp() {
        
    };
};

export default Cli